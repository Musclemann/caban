package pl.edu.pwr.ziwg.logic.category;

import org.springframework.stereotype.Component;
import pl.edu.pwr.ziwg.logic.category.api.CategoryAdapter;

@Component
public class CategoryMediator implements CategoryAdapter {
}
