package pl.edu.pwr.ziwg.logic.category.exceptions;

public class CategoryNullException extends Exception {

    public CategoryNullException() {
        super();
    }
}
