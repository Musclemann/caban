package pl.edu.pwr.ziwg.logic.category.api;

public interface CategoryAdapter {

}
