package pl.edu.pwr.ziwg.logic.customer.exceptions;

public class CustomerNotFoundException extends Exception {

    public CustomerNotFoundException() {
        super();
    }
}
