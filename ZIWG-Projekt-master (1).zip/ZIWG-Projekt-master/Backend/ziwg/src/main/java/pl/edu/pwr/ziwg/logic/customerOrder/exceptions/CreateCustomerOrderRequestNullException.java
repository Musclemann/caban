package pl.edu.pwr.ziwg.logic.customerOrder.exceptions;

public class CreateCustomerOrderRequestNullException extends Exception {

    public CreateCustomerOrderRequestNullException() {
        super();
    }
}
