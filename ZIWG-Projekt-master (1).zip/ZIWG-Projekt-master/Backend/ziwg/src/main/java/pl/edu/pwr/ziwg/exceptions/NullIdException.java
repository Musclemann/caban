package pl.edu.pwr.ziwg.exceptions;

import pl.edu.pwr.ziwg.models.Product;

public class NullIdException extends Exception {

    public NullIdException() {
        super();
    }
}
