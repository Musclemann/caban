package pl.edu.pwr.ziwg.logic.product.exceptions;

public class GetProductRequestNullException extends Exception {

    public GetProductRequestNullException() {
        super();
    }
}
