INSERT INTO category (name) VALUES ('FISHING_ROD');
INSERT INTO category (name) VALUES ('LANDING_NET');
INSERT INTO category (name) VALUES ('REEL');
INSERT INTO category (name) VALUES ('HOOK');
INSERT INTO category (name) VALUES ('BAIT');