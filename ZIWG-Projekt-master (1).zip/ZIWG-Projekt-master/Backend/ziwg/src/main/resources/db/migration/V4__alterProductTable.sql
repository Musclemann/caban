ALTER TABLE product
ADD added_date date;

UPDATE product
SET added_date = '2023-05-17';