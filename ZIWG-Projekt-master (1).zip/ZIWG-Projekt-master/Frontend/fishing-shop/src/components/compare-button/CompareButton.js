import "../compare-button/CompareButton.css";

const CompareButton = () => {
  return (
    <div className="compare-button-container">
      <span className="material-symbols-outlined">compare_arrows</span>
    </div>
  );
};

export default CompareButton;
